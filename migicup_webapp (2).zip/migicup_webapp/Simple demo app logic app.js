// Simple demo app logic
const stationsEl = document.getElementById('stations');
const imuStatusEl = document.getElementById('imuStatus');
const bufferEl = document.getElementById('bufferLevel');
const netEl = document.getElementById('netStatus');
const locateBtn = document.getElementById('locateBtn');
const modal = document.getElementById('modal');
const confirmReserve = document.getElementById('confirmReserve');
const cancelReserve = document.getElementById('cancelReserve');
const mascot = document.getElementById('mascot');

let stations = [
  {id:1, name:'Migicup - Lawson Shinjuku', dist:'120 m', avail:true},
  {id:2, name:'Migicup - FamilyMart Ebisu', dist:'420 m', avail:true},
  {id:3, name:'Migicup - Local Market Ginza', dist:'680 m', avail:false},
];

function renderStations(){
  stationsEl.innerHTML = '';
  stations.forEach(s => {
    const li = document.createElement('li');
    li.className = 'station';
    li.innerHTML = `
      <div class="meta">
        <div class="name">${s.name}</div>
        <div class="sub">${s.dist} • ${s.avail ? 'Available' : 'Occupied'}</div>
      </div>
      <div>
        <button ${s.avail? '' : 'disabled'} data-id="${s.id}">${s.avail ? 'Reserve' : 'View'}</button>
      </div>
    `;
    stationsEl.appendChild(li);
  });
}
renderStations();

stationsEl.addEventListener('click', (e)=>{
  const btn = e.target.closest('button');
  if(!btn) return;
  const id = Number(btn.dataset.id);
  openReserve(id);
});

function openReserve(id){
  const st = stations.find(s=>s.id===id);
  document.getElementById('modalTitle').innerText = 'Reserve: ' + st.name;
  document.getElementById('modalDesc').innerText = 'Reserve spot for 15 minutes. Price: ¥100';
  modal.classList.remove('hidden');
}

confirmReserve.addEventListener('click', ()=>{
  // simple simulate reservation success
  modal.classList.add('hidden');
  alert('Reserved! Head to spot within 15 minutes.');
});

cancelReserve.addEventListener('click', ()=>{
  modal.classList.add('hidden');
});

locateBtn.addEventListener('click', ()=> {
  alert('Searching nearby Migicup stations (demo) ...');
});

// simulate IMU activity
let imuState = 'idle';
function simulateIMU(){
  const r = Math.random();
  if(r < 0.02){
    imuState = 'busy';
    imuStatusEl.innerText = 'vehicle arriving';
  } else if (r < 0.05){
    imuState = 'occupied';
    imuStatusEl.innerText = 'occupied';
  } else {
    imuState = 'idle';
    imuStatusEl.innerText = 'idle';
  }
  // buffer fluctuate
  const cur = parseInt(bufferEl.innerText);
  let delta = Math.round((Math.random()-0.45)*3);
  let next = Math.min(100, Math.max(20, cur + delta));
  bufferEl.innerText = next + '%';
}
setInterval(simulateIMU, 2500);

// mascot interaction (anime-style short dialog)
mascot.addEventListener('click', ()=>{
  const lines = [
    'Mint-chan: Need a quick charge? I\\'m here!',
    'Mint-chan: Reserve a spot and enjoy a coffee nearby.',
    'Mint-chan: Did you know? Migicup uses recycled materials.'
  ];
  const txt = lines[Math.floor(Math.random()*lines.length)];
  alert(txt);
});
